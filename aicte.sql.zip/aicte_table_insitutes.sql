
-- --------------------------------------------------------

--
-- Table structure for table `insitutes`
--

CREATE TABLE `insitutes` (
  `Serial` int(11) NOT NULL,
  `Parent_University_ID` int(10) DEFAULT NULL,
  `Institute_ID` int(10) DEFAULT NULL,
  `Institue_Name` text,
  `State` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
