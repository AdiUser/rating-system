
-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Serial` int(11) NOT NULL,
  `University_ID` int(10) DEFAULT NULL,
  `Name` mediumtext,
  `Qualification` text,
  `Joining_Date` date DEFAULT NULL,
  `Department` text,
  `Subject` text,
  `Level` text NOT NULL,
  `Faculty_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`Serial`, `University_ID`, `Name`, `Qualification`, `Joining_Date`, `Department`, `Subject`, `Level`, `Faculty_ID`) VALUES
(1, 12345678, 'Faculty1', 'PHD', '0000-00-00', 'Computer Science', 'Subject1', '9', 201),
(2, 12345678, 'Faculty2', 'Mtech', '2017-06-07', 'Mechanical', 'Thermodynamics', '9', 203),
(3, 12345678, 'Faculty3', 'Mtech', '2010-04-12', 'Electrical', 'SubjectXYZ', '9', 202),
(4, 12345678, 'Faculty4', 'MSc.', '2007-07-25', 'Electronics', 'SubjectABC', '13A1', 204);
