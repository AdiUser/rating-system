
-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `Serial` int(11) NOT NULL,
  `Faculty_ID` int(11) NOT NULL,
  `Feedback_From_ID` int(11) NOT NULL,
  `Teaching_Process` int(11) NOT NULL,
  `Student_Feedback` int(11) NOT NULL,
  `Departmental_Activity` int(11) NOT NULL,
  `Institutional_Activity` int(11) NOT NULL,
  `ACR` int(11) NOT NULL,
  `Contribution_To_Society` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
