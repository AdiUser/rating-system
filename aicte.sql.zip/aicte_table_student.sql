
-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Serial` int(11) NOT NULL,
  `University_Roll_Number` int(10) DEFAULT NULL,
  `Name` text,
  `Course` text NOT NULL,
  `Semester` int(11) NOT NULL,
  `Batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
