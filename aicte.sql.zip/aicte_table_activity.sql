
-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `Serial` int(11) NOT NULL,
  `Faculty_ID` int(10) DEFAULT NULL,
  `Name` text,
  `Report` int(11) DEFAULT NULL,
  `Verified` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
