
-- --------------------------------------------------------

--
-- Table structure for table `university`
--

CREATE TABLE `university` (
  `Serial` int(11) NOT NULL,
  `University_Code` int(10) DEFAULT NULL,
  `Name` text,
  `State` text,
  `Is_State_University` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `university`
--

INSERT INTO `university` (`Serial`, `University_Code`, `Name`, `State`, `Is_State_University`) VALUES
(1, 12345678, 'Graphic Era Deemed To Be University', 'Uttarakhand', 'No'),
(2, 12345679, 'DIT University', 'Uttarakhand', 'Yes');
