
-- --------------------------------------------------------

--
-- Table structure for table `aicte admin`
--

CREATE TABLE `aicte admin` (
  `Serial` int(11) NOT NULL,
  `University_Code` int(10) DEFAULT NULL,
  `University_Name` text NOT NULL,
  `Contact` int(11) NOT NULL,
  `Address` longtext,
  `Email` mediumtext,
  `Verified` int(11) NOT NULL,
  `Excel File` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aicte admin`
--

INSERT INTO `aicte admin` (`Serial`, `University_Code`, `University_Name`, `Contact`, `Address`, `Email`, `Verified`, `Excel File`) VALUES
(1, 12345678, 'Graphic Era Deemed To Be University', 1234567890, '555/6,Bell Road,Clement Town,Dehradun,Uttarakhand', 'geuddn@gmail.com', 0, 0),
(3, 12345679, 'DIT University', 12651253, 'Mussorie Road,Dehradun,Uttarakhand', 'ditdn@gmail.com', 0, 0);
